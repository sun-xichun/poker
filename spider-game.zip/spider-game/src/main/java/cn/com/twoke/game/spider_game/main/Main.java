package cn.com.twoke.game.spider_game.main;


public class Main {
	
	public static void main(String[] args) {
		new SpiderGame();
	}
}
