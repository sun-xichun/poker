package cn.com.twoke.game.spider_game.entity;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import cn.com.twoke.game.spider_game.animation.Animation;
import cn.com.twoke.game.spider_game.constant.ImageResource;
import cn.com.twoke.game.spider_game.enums.PokerNoEnum;
import cn.com.twoke.game.spider_game.enums.PokerTypeEnum;
import cn.com.twoke.game.spider_game.utils.ImageUtils;

import static cn.com.twoke.game.spider_game.config.Global.*;

/**
 * 表示一张扑克牌的类。
 */
public class Poker {
	private PokerNoEnum no;               // 扑克牌的数字枚举
	private PokerTypeEnum type;           // 扑克牌的花色枚举
	private boolean turnOver;             // 标志扑克牌是否翻转
	private Animation fireAnimation;      // 火焰动画
	private Animation completedAnimation; // 完成动画

	/**
	 * 构造方法，初始化扑克牌的数字和花色，并初始化动画。
	 *
	 * @param no 扑克牌的数字枚举
	 * @param type 扑克牌的花色枚举
	 */
	public Poker(PokerNoEnum no, PokerTypeEnum type) {
		this.no = no;
		this.type = type;
		fireAnimation = new Animation(15);  // 初始化火焰动画，总帧数为15
		completedAnimation = new Animation(); // 初始化完成动画，使用默认构造方法
	}

	/**
	 * 检查火焰动画是否正在播放。
	 *
	 * @return 如果火焰动画正在播放返回true，否则返回false。
	 */
	public boolean isFiring() {
		return fireAnimation.isRuning();
	}

	/**
	 * 检查完成动画是否正在播放。
	 *
	 * @return 如果完成动画正在播放返回true，否则返回false。
	 */
	public boolean isCompleted() {
		return completedAnimation.isRuning();
	}

	/**
	 * 启动火焰动画。
	 */
	public void fire() {
		fireAnimation.startAnimation();
	}

	/**
	 * 启动完成动画。
	 */
	public void completed() {
		completedAnimation.startAnimation();
	}

	/**
	 * 根据扑克牌的花色和数字获取正面图片。
	 *
	 * @return 对应花色和数字的正面图片。
	 */
	private BufferedImage getFaceImage() {
		switch (type) {
			case HEI:
				return ImageResource.POKER_HEIS[no.getId()];
			case HONG:
				return ImageResource.POKER_HONGS[no.getId()];
			case MEI:
				return ImageResource.POKER_MEIS[no.getId()];
			case FANG:
				return ImageResource.POKER_FANGS[no.getId()];
			default:
				return null;
		}
	}

	/**
	 * 更新扑克牌的动画状态。
	 * 在游戏循环中调用以更新动画帧。
	 */
	public void update() {
		fireAnimation.update();
		completedAnimation.update();
	}

	/**
	 * 绘制扑克牌。
	 *
	 * @param g 绘图对象
	 * @param startX 起始绘制位置的X坐标
	 * @param startY 起始绘制位置的Y坐标
	 * @param isFace 是否显示正面
	 */
	public void draw(Graphics g, int startX, int startY, boolean isFace) {
		BufferedImage image = ImageResource.POKER_BACK;
		if (isFace && !fireAnimation.isRuning()) {
			image = getFaceImage();
		}
		g.drawImage(image, startX, startY, POKER_WIDTH, POKER_HEIGHT, null);
		g.drawImage(ImageResource.POKER_MASK, startX, startY, POKER_WIDTH, POKER_HEIGHT, null);
	}

	/**
	 * 绘制扑克牌的反面。
	 *
	 * @param g 绘图对象
	 * @param startX 起始绘制位置的X坐标
	 * @param startY 起始绘制位置的Y坐标
	 */
	public void drawMask(Graphics g, int startX, int startY) {
		BufferedImage image = getFaceImage();
		g.drawImage(ImageUtils.inverse(image), startX, startY, POKER_WIDTH, POKER_HEIGHT, null);
	}

	/**
	 * 获取扑克牌的数字。
	 *
	 * @return 扑克牌的数字枚举。
	 */
	public PokerNoEnum getNo() {
		return no;
	}

	/**
	 * 获取扑克牌的花色。
	 *
	 * @return 扑克牌的花色枚举。
	 */
	public PokerTypeEnum getType() {
		return type;
	}

	/**
	 * 检查扑克牌是否翻转。
	 *
	 * @return 如果扑克牌已翻转返回true，否则返回false。
	 */
	public boolean isTurnOver() {
		return turnOver;
	}

	/**
	 * 设置扑克牌的翻转状态。
	 *
	 * @param turnOver 如果为true表示扑克牌已翻转，否则未翻转。
	 */
	public void setTurnOver(boolean turnOver) {
		this.turnOver = turnOver;
	}
}
