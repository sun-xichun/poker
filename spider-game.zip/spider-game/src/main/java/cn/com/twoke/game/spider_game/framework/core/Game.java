package cn.com.twoke.game.spider_game.framework.core;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.function.Function;

/**
 * 游戏启动
 */
/**
 * 游戏抽象类，实现了Runnable接口，用于创建基本游戏循环。
 */
public abstract class Game implements Runnable {

    /**
     * 设定每秒帧数（FPS）
     */
    public static final int FPS_SET = 120;

    /**
     * 设定每秒更新次数（UPS）
     */
    public static final int UPS_SET = 200;

    // 游戏面板
    protected final GamePanel panel;

    // 游戏窗口
    protected final GameWindow window;

    // 绘制游戏的线程
    private Thread drawThread;

    /**
     * 游戏的构造函数，接收一个用于获取游戏面板的函数。
     * @param panelGetter 用于获取游戏面板的函数
     */
    public Game(Function<Game, GamePanel> panelGetter) {
        initialzer();
        this.panel = panelGetter.apply(this);
        this.window = new GameWindow(panel);
        this.panel.requestFocus();
        startDrawGameLoop();
    }

    /**
     * 启动游戏绘制循环的方法。
     */
    protected void startDrawGameLoop() {
        drawThread = new Thread(this);
        drawThread.start();
    }

    /**
     * 实现Runnable接口的run方法，主要负责游戏的帧更新和绘制。
     */
    @Override
    public void run() {
        // 计算每帧和每次更新所需的时间
        double timePerFrame = 1_000_000_000.0 / FPS_SET;
        double timePerUpdate = 1_000_000_000.0 / UPS_SET;

        // 记录上次检查时间
        long lastCheck = System.currentTimeMillis();

        // 记录上次循环开始的时间
        long previousTime = System.nanoTime();

        // 记录帧数和更新次数
        int frames = 0;
        int updates = 0;

        // 用于累计时间以判断是否进行更新或绘制
        double deltaU = 0;
        double deltaF = 0;

        while (true) { // 游戏循环
            long currentTime = System.nanoTime();

            // 计算距离上次更新的时间累积
            deltaU += (currentTime - previousTime) / timePerUpdate;
            // 计算距离上次绘制的时间累积
            deltaF += (currentTime - previousTime) / timePerFrame;

            previousTime = currentTime;

            // 如果累积时间达到一个更新周期，则进行更新
            if (deltaU >= 1) {
                update();
                updates++;
                deltaU--;
            }

            // 如果累积时间达到一个绘制周期，则进行绘制
            if (deltaF >= 1) {
                panel.repaint();
                frames++;
                deltaF--;
            }

            // 每秒钟检查一次帧率和更新率
            if (System.currentTimeMillis() - lastCheck >= 1000) {
                lastCheck = System.currentTimeMillis();
                System.out.println("FPS: " + frames + " | UPS: " + updates);
                frames = 0;
                updates = 0;
            }
        }
    }

    /**
     * 当窗口失去焦点时调用的方法，子类可以覆盖该方法以实现特定的行为。
     */
    public void windowLostFocus() {
        // 窗口失去焦点时的处理逻辑，子类根据需要实现
    }

    /**
     * 初始化方法，子类可以覆盖该方法以进行额外的初始化操作。
     */
    protected void initialzer() {
        // 游戏初始化逻辑，子类根据需要实现
    }

    /**
     * 绘制游戏的方法，由子类实现具体的绘制逻辑。
     * @param drawGraphics 绘图用的Graphics对象
     */
    public void draw(Graphics drawGraphics) {
        int height = this.panel.size().height;
        int width = this.panel.size().width;
        BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics g = bufferedImage.getGraphics();
        doDraw(g); // 调用子类实现的绘制方法
        drawGraphics.drawImage(bufferedImage, 0, 0, width, height, null);
    }

    /**
     * 抽象方法，由子类实现具体的绘制逻辑。
     * @param g 绘图用的Graphics对象
     */
    protected abstract void doDraw(Graphics g);

    /**
     * 更新游戏状态的方法，子类可以覆盖该方法以实现具体的更新逻辑。
     */
    protected void update() {
        // 游戏更新逻辑，子类根据需要实现
    }
}
