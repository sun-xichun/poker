package cn.com.twoke.game.spider_game.enums;

public enum PokerTypeEnum {
	HEI, HONG, MEI, FANG;
}
