package cn.com.twoke.game.spider_game.animation;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class Animation {
	// 实例变量声明
	public int aniIndex = 0;  // 当前动画帧的索引
	public int aniCount;      // 动画总帧数
	public List<Consumer<Integer>> listeners;  // 动画更新时通知的监听器列表
	public boolean aniFlag = false;  // 标志动画是否正在运行

	// 构造方法1：默认构造方法，初始化时aniCount = 10
	public Animation() {
		this(10);
	}

	// 构造方法2：带参数的构造方法
	// 根据给定的aniCount初始化，同时初始化listeners为空的ArrayList
	public Animation(int aniCount) {
		this.aniCount = aniCount;
		this.listeners = new ArrayList<>();
	}

	// 方法：启动动画
	public void startAnimation() {
		this.aniFlag = true;
	}

	// 方法：结束动画
	public void endAnimation() {
		this.aniFlag = false;
	}

	// 方法：检查动画是否在运行
	public boolean isRuning() {
		return aniFlag;
	}

	// 方法：更新动画帧
	public void update() {
		if (aniFlag) {  // 只有在动画运行时才更新
			if (aniIndex > aniCount) {  // 如果当前帧索引超过了总帧数
				aniIndex = 0;  // 将索引重置为开始处
				endAnimation();  // 结束动画（将aniFlag设为false）
			}
			// 遍历所有监听器，并通知它们当前的aniIndex
			listeners.forEach(listener -> listener.accept(aniIndex));
			aniIndex++;  // 移动到下一个动画帧索引
		}
	}
}
